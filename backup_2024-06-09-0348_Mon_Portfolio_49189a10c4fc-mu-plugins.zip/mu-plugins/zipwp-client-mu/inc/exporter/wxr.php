<?php
/**
 * Surecart Settings Exporter.
 *
 * @package {{package}}
 * @since 1.1.0
 */

namespace ZIPWP_CLIENT\Inc\Exporter;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use ZIPWP_CLIENT\Inc\Traits\Instance;

/**
 * Surecart Settings
 *
 * @since 1.1.0
 */
class WXR {

	use Instance;

	/**
	 * Export options.
	 *
	 * @since 1.1.0 Added static known option for export.
	 *
	 * @return string WXR URL.
	 */
	public function export() {
		require_once ABSPATH . 'wp-admin/includes/export.php';
		// Fix: Skip meta while exporting.
		add_filter(
			'wxr_export_skip_postmeta',
			function( $return_me, $meta_key ) {

				$skip_these_meta_keys = array(
					'_action_manager_schedule',
					'_edd_download_sales',
				);

				if ( in_array( $meta_key, $skip_these_meta_keys, true ) ) {
					$return_me = true;
				}

				return $return_me;
			},
			10,
			2
		);
		$args['content'] = 'all';

		// Exclude post types!
		foreach ( (array) $this->get_excluded_post_types_from_wxr()  as $key => $post_type ) {
			unregister_post_type( $post_type );
		}

		// Exclude taxonomies!
		foreach ( (array) $this->get_excluded_taxonomies_from_wxr()  as $key => $taxonomy ) {
			unregister_taxonomy( $taxonomy );
		}

		ob_start();
		export_wp( $args );
		$wxr    = ob_get_clean();
		$dest   = defined( 'WP_CONTENT_DIR' ) ? WP_CONTENT_DIR . '/uploads/wxr.xml' : '';
		$result = file_put_contents( $dest, $wxr ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_file_put_contents

		if ( false !== $result ) {
			return site_url() . '/wp-content/uploads/wxr.xml';
		}
		return '';
	}

	/**
	 * Exclude Post Types
	 *
	 * Exclude post types from the generated XML file.
	 *
	 * @since 1.1.0
	 * @return array<int,string>
	 */
	public function get_excluded_post_types_from_wxr() {
		return array(
			// Plugin: GiveWP.
			'give_forms',
			'give_payment',

			// Plugin: Brizy.
			'brizy-project',
			'brizy-global-block',
			'brizy-saved-block',
			'brizy_template',

			// Plugin: Cartflows.
			'cartflows_step',
			'cartflows_flow',

			// Plugin: WooCommerce.
			'shop_order',
			'shop_coupon',
			'scheduled-action',

			// Plugin: Astra Sites Server.
			'astra-sites',
			'site-pages',
			'astra-blocks',

			// Plugin: Contact Form 7.
			'wpcf7_contact_form',
		);
	}

	/**
	 * Exclude Post Types
	 *
	 * Exclude post types from the generated XML file.
	 *
	 * @since 1.1.0
	 * @return array<int,string>
	 */
	public function get_excluded_taxonomies_from_wxr() {
		return array(

			// Plugin: Cartflows.
			'cartflows_step_flow',
			'cartflows_step_type',

			// Plugin: WooCommerce.
			'action-group',

			// Plugin: Astra Sites Server.
			'astra-site-page-builder',
			'site-pages-page-builder',
			'site-pages-type',
			'astra-sites-type',
			'astra-site-category',
			'astra-sites-tag',
			'site-pages-parent-site',
			'site-pages-parent-category',
			'astra-blocks-tag',
			'blocks-category',
			'pages-category',
		);
	}
}
