<?php
/**
 * Spectra Settings Exporter.
 *
 * @package {{package}}
 * @since 1.1.0
 */

namespace ZIPWP_CLIENT\Inc\Exporter;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use ZIPWP_CLIENT\Inc\Traits\Instance;

/**
 * Spectra Settings
 *
 * @since 1.1.0
 */
class Spectra {

	use Instance;

	/**
	 * Export options.
	 *
	 * @since 1.1.0 Added static known option for export.
	 *
	 * @return string Array of customiser settings.
	 */
	public function export() {
		if ( is_callable( 'UAGB_Admin_Helper::get_instance' ) ) {
			$settings = class_exists( 'UAGB_Admin_Helper' ) ? \UAGB_Admin_Helper::get_instance()->get_admin_settings_shareable_data() : [];
			$dest     = defined( 'WP_CONTENT_DIR' ) ? WP_CONTENT_DIR . '/uploads/spectra.json' : '';
			$result   = file_put_contents( $dest, wp_json_encode( $settings ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_file_put_contents

			if ( false !== $result ) {
				return site_url() . '/wp-content/uploads/spectra.json';
			}
		}
		return '';
	}

	/**
	 * Get Site URI
	 *
	 * @since 1.1.0
	 * @return string Site URI.
	 */
	public function get_site_uri() {
		return site_url() . '/wp-content/uploads/zip-site/';
	}

	/**
	 * Get Uploads Directory
	 *
	 * @since 1.1.0
	 *
	 * @return string Uploads Directory URI.
	 */
	public function get_uploads_dir() {
		return defined( 'WP_CONTENT_DIR' ) ? WP_CONTENT_DIR . '/uploads/zip-site/' : '';
	}
}
