<?php
/**
 * Options Exporter.
 *
 * @package {{package}}
 * @since 1.1.0
 */

namespace ZIPWP_CLIENT\Inc\Exporter;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use ZIPWP_CLIENT\Inc\Traits\Instance;

/**
 * Options
 *
 * @since 1.1.0
 */
class Options {

	use Instance;

	/**
	 * Export options.
	 *
	 * @since 1.1.0 Added static known option for export.
	 *
	 * @return array<string,array<mixed>> Array of site options.
	 */
	public function export() {

		$options = array(
			'custom_logo'        => $this->get_custom_logo_src(), // Custom Logo.
			'nav_menu_locations' => $this->get_nav_menu_locations(), // Nav Menu Locations.
			'show_on_front'      => get_option( 'show_on_front', null ), // Set show on front option.
			'page_on_front'      => get_the_title( get_option( 'page_on_front' ) ), // Set page on front option.
			'page_for_posts'     => get_the_title( get_option( 'page_for_posts' ) ), // Set page for posts option.
			'site_title'         => get_option( 'blogname' ), // Set blogname option.
		);

		// Astra Global Color Palette option.
		if ( function_exists( 'astra_get_palette_colors' ) ) {
			$options['astra-color-palettes'] = astra_get_palette_colors();
		}

		// Astra Typography Preset option.
		if ( function_exists( 'astra_get_typography_presets' ) ) {
			$options['astra-typography-presets'] = astra_get_typography_presets();
		}

		return $options;
	}

	/**
	 * In WP Navigation menu is stored as ( 'menu_location' => 'menu_id' );
	 * In export we send 'menu_slug' like ( 'menu_location' => 'menu_slug' );
	 * In import we set 'menu_id' from menu slug like ( 'menu_location' => 'menu_id' );
	 *
	 * @since 1.1.0
	 * @return array<string,string>
	 */
	private function get_nav_menu_locations() {

		$menu_location_with_menu_slug = array();

		foreach ( get_nav_menu_locations() as $slug => $assigned_menu_id ) {
			$term = get_term_by( 'id', $assigned_menu_id, 'nav_menu' );
			if ( is_object( $term ) ) {
				$menu_location_with_menu_slug[ $slug ] = $term->slug;
			}
		}

		return $menu_location_with_menu_slug;

	}

	/**
	 * Get Custom Logo URL.
	 *
	 * @since 1.1.0
	 * @return string
	 */
	public function get_custom_logo_src() {
		$custom_logo_id = get_theme_mod( 'custom_logo' );
		$src            = '';
		$image          = wp_get_attachment_image_src( $custom_logo_id, 'full' );
		if ( $image ) {
			list($src, $width, $height) = $image;
			return $src;
		} else {
			return '';
		}
	}
}
