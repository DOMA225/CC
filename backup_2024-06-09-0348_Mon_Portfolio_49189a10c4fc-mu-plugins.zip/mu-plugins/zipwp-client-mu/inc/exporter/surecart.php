<?php
/**
 * Surecart Settings Exporter.
 *
 * @package {{package}}
 * @since 1.1.0
 */

namespace ZIPWP_CLIENT\Inc\Exporter;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use ZIPWP_CLIENT\Inc\Traits\Instance;

/**
 * Surecart Settings
 *
 * @since 1.1.0
 */
class Surecart {

	use Instance;

	/**
	 * Export options.
	 *
	 * @since 1.1.0 Added static known option for export.
	 *
	 * @return array<string,string> Array of customiser settings.
	 */
	public function export() {
		if ( ! ( is_plugin_active( 'surecart/surecart.php' ) && class_exists( 'SureCart' ) && is_callable( 'SureCart::account' ) ) ) {
			return [];
		}
		$id = \SureCart::account()->id;
		$id = null !== $id ? $id : '';
		if ( ! $id ) {
			return [];
		}
		$currency     = \SureCart::account()->currency;
		$currency     = ( '' !== $currency ) ? $currency : 'usd';
		$encoded_data = base64_encode( $id ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
		return array(
			'id'       => $encoded_data,
			'currency' => $currency,
		);
	}
}
