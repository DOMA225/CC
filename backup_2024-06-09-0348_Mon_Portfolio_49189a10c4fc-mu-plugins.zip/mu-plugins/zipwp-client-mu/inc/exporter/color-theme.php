<?php
/**
 * ColorTheme Exporter.
 *
 * @package {{package}}
 * @since 1.1.0
 */

namespace ZIPWP_CLIENT\Inc\Exporter;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use ZIPWP_CLIENT\Inc\Traits\Instance;

/**
 * ColorTheme
 *
 * @since 1.1.0
 */
class ColorTheme {

	use Instance;

	/**
	 * Export color scheme.
	 *
	 * @since 1.1.0
	 *
	 * @return string light/dark.
	 */
	public function export() {
		$site_data = get_option( 'zipwp_site_data', [] );
		return isset( $site_data['color_scheme'] ) ? $site_data['color_scheme'] : 'light';
	}
}
