<?php
/**
 * Customizer Exporter.
 *
 * @package {{package}}
 * @since 1.1.0
 */

namespace ZIPWP_CLIENT\Inc\Exporter;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use ZIPWP_CLIENT\Inc\Traits\Instance;

/**
 * Customizer
 *
 * @since 1.1.0
 */
class Customizer {

	use Instance;

	/**
	 * Export options.
	 *
	 * @since 1.1.0 Added static known option for export.
	 *
	 * @return array<string,array<int,mixed>> Array of customiser settings.
	 */
	public function export() {
		$theme_options = array();

		// Astra Settings.
		$theme_options['astra-settings'] = class_exists( 'Astra_Theme_Options' ) && is_callable( '\Astra_Theme_Options::get_options' ) ? \Astra_Theme_Options::get_options() : array();

		// Customizer CSS.
		$theme_options['custom-css'] = wp_get_custom_css();

		return $theme_options;
	}
}
