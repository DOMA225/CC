<?php
/**
 * Zip WP CLI
 *
 * 1. Run `wp zipwp export` List of all Zip.
 *
 * @package zipwp-client
 * @since 1.1.0
 */

namespace ZIPWP_CLIENT\Inc\Exporter;

use WP_CLI;
use ZIPWP_CLIENT\Inc\Traits\Instance;
use ZIPWP_CLIENT\Inc\Admin\Dashboard;

/**
 * WP-Cli commands to manage Astra Starter Sites.
 *
 * @since 1.1.0
 */
class ZipwpCli {

	use Instance;

	/**
	 * Export thh site.
	 *
	 * ## OPTIONS
	 *
	 * ## EXAMPLES
	 *
	 *     # Import demo site.
	 *     $ wp zipwp export
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function export() {
		if ( class_exists( 'WP_CLI' ) ) {
			// Start the export process.
			Dashboard::instance()->export();

			WP_CLI::line( __( 'Site exported successfully', 'zipwp-client' ) );
		}
	}
}

/**
 * Add Command
 */
if ( defined( 'WP_CLI' ) && class_exists( 'WP_CLI' ) ) {
	WP_CLI::add_command( 'zipwp-client', ZipwpCli::instance() );
}

