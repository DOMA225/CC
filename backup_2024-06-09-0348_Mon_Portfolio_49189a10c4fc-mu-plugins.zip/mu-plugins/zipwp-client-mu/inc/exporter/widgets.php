<?php
/**
 * Widgets Exporter.
 *
 * @package {{package}}
 * @since 1.1.0
 */

namespace ZIPWP_CLIENT\Inc\Exporter;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use ZIPWP_CLIENT\Inc\Traits\Instance;

/**
 * Widgets
 *
 * @since 1.1.0
 */
class Widgets {

	use Instance;

	/**
	 * Available widgets
	 *
	 * Gather site's widgets into array with ID base, name, etc.
	 * Used by export and import functions.
	 *
	 * @since 1.1.0
	 * @global array $wp_registered_widget_updates
	 * @return array<string,mixed> Widget information
	 */
	public function wie_available_widgets() {

		global $wp_registered_widget_controls;

		$widget_controls = $wp_registered_widget_controls;

		$available_widgets = array();

		foreach ( $widget_controls as $widget ) {

			if ( ! empty( $widget['id_base'] ) && ! isset( $available_widgets[ $widget['id_base'] ] ) ) {

				$available_widgets[ $widget['id_base'] ]['id_base'] = $widget['id_base'];
				$available_widgets[ $widget['id_base'] ]['name']    = $widget['name'];

			}
		}

		return apply_filters( 'wie_available_widgets', $available_widgets );
	}

	/**
	 * Generate export data
	 *
	 * @since 1.1.0
	 * @return string Export file contents.
	 */
	public function export() {

		// Get all available widgets site supports.
		$available_widgets = $this->wie_available_widgets();

		// Get all widget instances for each widget.
		$widget_instances = array();
		foreach ( $available_widgets as $widget_data ) {

			// Get all instances for this ID base.
			$instances = get_option( 'widget_' . $widget_data['id_base'] );

			// Have instances.
			if ( ! empty( $instances ) ) {

				// Loop instances.
				foreach ( $instances as $instance_id => $instance_data ) {

					// Key is ID (not _multiwidget).
					if ( is_numeric( $instance_id ) ) {
						$unique_instance_id = $widget_data['id_base'] . '-' . $instance_id;

						$updated_instance_data = $instance_data;

						if ( isset( $instance_data['nav_menu'] ) ) {
							$menu_obj                          = wp_get_nav_menu_object( $instance_data['nav_menu'] );
							$updated_instance_data['nav_menu'] = $menu_obj && ! empty( $menu_obj->slug ) ? $menu_obj->slug : '';
						}

						$widget_instances[ $unique_instance_id ] = $updated_instance_data;
					}
				}
			}
		}

		// Gather sidebars with their widget instances.
		$sidebars_widgets          = get_option( 'sidebars_widgets' ); // get sidebars and their unique widgets IDs.
		$sidebars_widget_instances = array();
		foreach ( $sidebars_widgets as $sidebar_id => $widget_ids ) {

			// Skip inactive widgets.
			if ( 'wp_inactive_widgets' === $sidebar_id ) {
				continue;
			}

			// Skip if no data or not an array (array_version).
			if ( ! is_array( $widget_ids ) || empty( $widget_ids ) ) {
				continue;
			}

			// Loop widget IDs for this sidebar.
			foreach ( $widget_ids as $widget_id ) {

				// Checking if there is an instance for this widget ID.
				if ( isset( $widget_instances[ $widget_id ] ) ) {

					// Add to array.
					$sidebars_widget_instances[ $sidebar_id ][ $widget_id ] = $widget_instances[ $widget_id ];

				}
			}
		}

		// Filter pre-encoded data.
		$data = apply_filters( 'wie_unencoded_export_data', $sidebars_widget_instances );

		// Encode the data for file contents.
		$encoded_data = wp_json_encode( $data );

		// Return contents.
		return apply_filters( 'wie_generate_export_data', $encoded_data );
	}
}
